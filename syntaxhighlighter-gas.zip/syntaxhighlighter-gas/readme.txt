=== SyntaxHighlighter Evolved: Google Apps Script ===
Tags: syntaxhighlighter, evolved, brush, syntax, highlighter, highlighting, google apps script
Requires at least: 3.9
Tested up to: 4.6.1
Contributors: mhawksey
Donate link: 
Stable tag: 1.0
License: GPLv2

Adds support for the Google Apps Script language to the SyntaxHighlighter Evolved plugin.

== Description ==
This simple WordPress plugin adds support for the Google Apps Script language, extending the SyntaxHighlighter Evolved plugin.
**Requires SyntaxHighlighter Evolved plugin to be installed first.**

== Installation ==
1. Make sure the Syntaxhighlighter Evolved plugin is installed.
2. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
1. how do I insert the code
2. [gs]Code Here![/gs]
3. [gas]Code Here![/gas]
4. [Google Apps Script]Code Here![/Google Apps Script]

== Screenshots ==

== Changelog ==
= 1.0 = 
Initial release.


